public abstract class Empleado {
    private String codigo;
    private String nombre;
    private String apellido;
    private String cargo;
    private double sueldo;


    public Empleado(){

    }

    public Empleado(String codigo, String nombre, String apellido, String cargo, double sueldo){
        if(codigo == null || codigo.isEmpty())
            throw new IllegalArgumentException("El codigo no puede estar vacio. ");
        if(nombre == null || nombre.isEmpty())
            throw new IllegalArgumentException("El nombre no puede estar vacio. ");
        if(apellido == null || apellido.isEmpty())
            throw new IllegalArgumentException("El apellido no puede estar vacio. ");
        if(cargo == null || cargo.isEmpty())
            throw new IllegalArgumentException("El cargo no puede estar vacio. ");
        if (sueldo < 0)
            throw new IllegalArgumentException("El sueldo no puede ser negativo. ");

        this.codigo = codigo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cargo = cargo;
        this.sueldo = sueldo;
    }


    public abstract double calcularSueldoTotal();

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    @Override
    public String toString(){
        return "\n=== INFORMACION DEL EMPLEADO ==="+
                "\nCodigo: "+codigo+
                "\nEmpleado: "+nombre+" "+apellido+
                "\nCargo: "+cargo+
                "\nSueldo base: "+sueldo;
    }
}
