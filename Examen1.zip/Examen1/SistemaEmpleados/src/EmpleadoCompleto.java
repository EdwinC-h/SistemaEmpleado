import java.util.Scanner;

public class EmpleadoCompleto extends Empleado{
    private double bono;

    Scanner sc = new Scanner(System.in);
    public EmpleadoCompleto(String codigo,String nombre, String apellido, String cargo, double sueldo, double bono){
        super(codigo, nombre, apellido, cargo, sueldo);
        if (bono <= 0)
            throw new IllegalArgumentException("El bono no puede ser negativo. ");
        this.bono = bono;
    }


    @Override
    public double calcularSueldoTotal(){
        return getSueldo()*bono;
    }


    public double getBono() {
        return bono;
    }

    public void setBono(double bono) {
        this.bono = bono;
    }
}
