public class EmpleadoMedioTiempo extends Empleado{
    private int horasTrabajadas;
    private double pagoPorHora;

    public EmpleadoMedioTiempo(String codigo, String nombre, String apellido, String cargo, double sueldo, int horasTrabajadas, double pagoPorHora) {
        super(codigo, nombre, apellido, cargo, sueldo);
        if (horasTrabajadas < 2)//Un empleado no podria trabajar por 0 horas o 1 hora al dia, almenos 2 horas por dia.
            throw new IllegalArgumentException("La horas trabajadas no pueden ser menores que 2. ");
        if (pagoPorHora < 0)
            throw new IllegalArgumentException("El pago por horas no puede ser negativo. ");
        this.horasTrabajadas = horasTrabajadas;
        this.pagoPorHora = pagoPorHora;
    }

    @Override
    public double calcularSueldoTotal(){
        return getSueldo()+(horasTrabajadas*pagoPorHora);
    }


    public int getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public void setHorasTrabajadas(int horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public double getPagoPorHora() {
        return pagoPorHora;
    }

    public void setPagoPorHora(double pagoPorHora) {
        this.pagoPorHora = pagoPorHora;
    }
}
