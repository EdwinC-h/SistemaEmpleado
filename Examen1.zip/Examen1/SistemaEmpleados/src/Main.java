import java.nio.channels.ScatteringByteChannel;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<Empleado> empleados = new ArrayList<>();

        Scanner sc = new Scanner(System.in);
        try {
            while (true) {
                System.out.println("1. Registrar empleado tiempo completo");
                System.out.println("2. Registrar empleado medio tiempo");
                System.out.println("3. Mostrar empleados registrados");
                System.out.println("4. Mostrar Estadísticas.");
                System.out.println("5. Salir");
                System.out.println("Ingrese una opcion: ");
                int opcion = sc.nextInt();
                sc.nextLine();

                if (opcion == 1) {
                    System.out.println("Ingrese la informacion: ");
                    System.out.println("Codigo: ");
                    String codigo = sc.nextLine();
                    System.out.println("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.println("Apellido: ");
                    String apellido = sc.nextLine();
                    System.out.println("Cargo: ");
                    String cargo = sc.nextLine();
                    System.out.println("Sueldo: ");
                    double saldo = sc.nextDouble();
                    System.out.println("Bono: ");
                    double bono = sc.nextDouble();
                    Empleado e1 = new EmpleadoCompleto(codigo, nombre, apellido, cargo, saldo, bono);
                    empleados.add(e1);
                } else if (opcion == 2) {
                    System.out.println("Ingrese la informacion: ");
                    System.out.println("Codigo: ");
                    String codigo = sc.nextLine();
                    System.out.println("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.println("Apellido: ");
                    String apellido = sc.nextLine();
                    System.out.println("Cargo: ");
                    String cargo = sc.nextLine();
                    System.out.println("Sueldo: ");
                    double saldo = sc.nextDouble();
                    System.out.println("Horas trabajo: ");
                    int horas = sc.nextInt();
                    System.out.println("Pago por horas: ");
                    double pago = sc.nextDouble();
                    Empleado e2 = new EmpleadoMedioTiempo(codigo, nombre, apellido, cargo, saldo, horas, pago);
                    empleados.add(e2);
                } else if (opcion == 3) {
                    for (Empleado emp: empleados){
                        System.out.println(emp.toString());
                    }
                } else if (opcion == 4) {


                } else {
                    System.out.println("finalizado...");
                    break;
                }
            }
        }catch (throw new PersonalException("La opcion no es valida "));
        
    }
}