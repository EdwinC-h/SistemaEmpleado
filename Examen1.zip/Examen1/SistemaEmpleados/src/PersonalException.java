public class PersonalException extends Exception{
    public PersonalException(String mensaje){
        super(mensaje);
    }
}
